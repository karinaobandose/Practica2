import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';

const Procesar = () => {
    const location = useLocation();
    const contenido = location.state ? location.state.contenido : null;
    const [currentPage, setCurrentPage] = useState(0);
    const [numpage, setNumpage] = useState("string");
    const rowsPerPage = 25;

    const totalPages = Math.ceil((contenido.length - 1) / rowsPerPage);

    const pagianaanterior = () => {
        setCurrentPage((prevPage) => Math.max(prevPage - 1, 0));
    };

    const paginasiguiente = () => {
        setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages - 1));
    };
    
    const searchpage = () =>{
        setCurrentPage((prevPage) => Math.min(parseInt(numpage)-1));

    }

    const startIndex = currentPage * rowsPerPage + 1;
    const endIndex = Math.min(startIndex + rowsPerPage, contenido.length);
    const currentData = contenido.slice(startIndex, endIndex);

    return (
        <div>
            <h4>Conjunto de datos recopilados</h4>
            <br/>

            <table className="table table-striped">
                <thead>
                <tr>
                    {contenido[0].map((item: any, index: number) => <th key={index}>{item}</th>)}
                </tr>
                </thead>
                <tbody>
                {currentData.map((row: any, index: number) => (
                    <tr key={index}>
                        {row.map((item: any, index: number) => <td key={index}>{item}</td>)}
                    </tr>
                ))}
                </tbody>
            </table>

            <div className="pagination">
                <button onClick={pagianaanterior} disabled={currentPage === 0}>Anterior</button>
                <span> Page {currentPage + 1} of {totalPages} </span>
                <button onClick={paginasiguiente} disabled={currentPage === totalPages - 1}>Siguiente</button>
                <input type="number" id='Search' onChange={(e) => setNumpage(e.target.value)}/>
                <button onClick={searchpage}>search</button>
            </div>
        </div>
    )
}

export default Procesar;
